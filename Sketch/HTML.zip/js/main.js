$("textarea").keydown(function(e){
// Enter was pressed without shift key
if (e.keyCode == 13 && e.shiftKey)
{
    // prevent default behavior
    e.preventDefault();
}
else if (e.keyCode == 13 && !e.shiftKey){
  e.preventDefault();
}
});
